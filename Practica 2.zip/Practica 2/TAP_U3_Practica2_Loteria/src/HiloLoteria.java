
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

/**
 *
 * @author Alejandro
 */
public class HiloLoteria extends Thread {
    public Ventana p;
    
    public HiloLoteria(Ventana p){
        this.p=p;
    }
    
    public void run(){
        for (int i = 0; i <= 54; i++) {
            if(p.barajeada.get(i)>0){
            p.jLabel1.setIcon(new ImageIcon(this.getClass().getResource("/Imagenes/"+p.barajeada.get(i)+".png")));
            }
        
        try {
            sleep(5000);
        } catch (InterruptedException ex) {
            Logger.getLogger(HiloLoteria.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        
    
    }
    
    
}
