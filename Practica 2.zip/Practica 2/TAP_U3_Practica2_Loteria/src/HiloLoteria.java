
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

/**
 *
 * @author Alejandro
 */
public class HiloLoteria extends Thread {
    public Ventana p;
    int cont=0;
    String[] nombres = { "El Gallo", "El Diablo", "La Dama", "El Catrín", "El Paraguas", "La Sirena", "La Escalera",
            "La Botella", "El Barril", "El Árbol", "El Melón", "El Valiente", "El Gorrito", "La Muerte", "La Pera",
            "La Bandera", "El Bandolón", "El Violoncello", "La Garza", "El Pájaro", "La Mano", "La Bota", "La Luna",
            "El Cotorro", "El Borracho", "El Negrito", "El Corazón", "La Sandía", "El Tambor", "El Camarón",
            "Las Jaras", "El Músico", "La Araña", "El Soldado", "La Estrella", "El Cazo", "El Mundo", "El Apache",
            "El Nopal", "El Alacrán", "La Rosa", "La Calavera", "La Campana", "El Cantarito", "El Venado", "El Sol",
            "La Corona", "La Chalupa", "El Pino", "El Pescado", "La Palma","La Maceta","El Arpa","La Rana" };
    
    public HiloLoteria(Ventana p){
        this.p=p;
    }
    
    public void run(){
        for (int i = 0; i <= 54; i++) {
                if(p.barajeada.get(i)>0){
                    p.jLabel1.setIcon(new ImageIcon(this.getClass().getResource("/Imagenes/"+p.barajeada.get(i)+".png")));
                }
            if(p.loteria==false){
                try {
                    sleep(500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(HiloLoteria.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if(p.loteria==true){
                cont++;
                try {
                    sleep(500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(HiloLoteria.class.getName()).log(Level.SEVERE, null, ex);
                }
                p.mostrarMensaje(nombres[p.barajeada.get(i)]+", ");
                if(cont==7) {p.Buffer+="\n"; cont=0;}
            }
            
            if (i>=16){
                p.jButton3.setEnabled(true);
            }
        }
        
    
    }
    
    
}
